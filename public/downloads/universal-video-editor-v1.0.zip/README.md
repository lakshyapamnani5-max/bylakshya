# Universal Video Editor (v1.0)

Created by Lakshya.

Extract this archive into your project's `.agent/skills/universal-video-editor/` directory and follow `SKILL.md`.
