---
name: universal-video-editor
version: 1.0.0
author: Lakshya
description: Automated AI video editing skill for FFmpeg timelines, dynamic captions, and motion graphics.
---

# Universal Video Editor Skill

Use this skill with Claude Code, Cursor, or OpenAI Codex to turn raw footage and scripts into polished vertical or widescreen videos.

## Capabilities
1. Scene-aware silence trimming and beat-synced cuts via FFmpeg.
2. Animated ASS/SRT caption generation with keyword emphasis.
3. Motion graphic intro/outro cards and color-LUT grading.
4. Automated export presets for 16:9 YouTube, 9:16 Reels/Shorts, and 1:1 LinkedIn.

## Quick Start
```bash
python3 scripts/render_video.py --input raw_clip.mp4 --preset 9x16 --captions templates/captions_preset.ass --output final.mp4
```
