#!/usr/bin/env python3
"""Universal Video Editor — FFmpeg render pipeline helper."""
import argparse
import subprocess
import sys

def build_ffmpeg_command(input_path: str, output_path: str, preset: str, captions: str | None) -> list[str]:
    scale_filter = {
        "16x9": "scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2",
        "9x16": "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920",
        "1x1": "scale=1080:1080:force_original_aspect_ratio=increase,crop=1080:1080",
    }.get(preset, "scale=1920:1080")
    vf = f"{scale_filter},ass={captions}" if captions else scale_filter
    return ["ffmpeg", "-y", "-i", input_path, "-vf", vf, "-c:v", "libx264", "-crf", "18", "-c:a", "aac", output_path]

def main() -> int:
    parser = argparse.ArgumentParser(description="Render AI-edited video timelines.")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--preset", default="16x9", choices=["16x9", "9x16", "1x1"])
    parser.add_argument("--captions", default=None)
    args = parser.parse_args()
    cmd = build_ffmpeg_command(args.input, args.output, args.preset, args.captions)
    print("Executing:", " ".join(cmd))
    return subprocess.call(cmd)

if __name__ == "__main__":
    sys.exit(main())
