#!/usr/bin/env bash
set -euo pipefail
python3 scripts/render_video.py --input sample.mp4 --preset 16x9 --output rendered.mp4
